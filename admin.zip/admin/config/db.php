<?php
// Set default timezone for the application
date_default_timezone_set('Asia/Kolkata');

$host = getenv('DB_HOST') ?: 'localhost';
$dbname = getenv('DB_NAME') ?: 'anrf1';
$user = getenv('DB_USER') ?: 'anrfpair1';
$pass = getenv('DB_PASS') ?: 'Anrfpair@123';

require_once __DIR__ . '/approval_helper.php';

try {

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    die("Connection failed: " . $e->getMessage());

}